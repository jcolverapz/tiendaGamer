from telethon import TelegramClient, events
from telethon.sync import TelegramClient
from telethon import functions, types
from telethon.tl.functions.channels import GetParticipantsRequest
from telethon.tl.functions.channels import GetFullChannelRequest
from telethon.tl.functions.contacts import ResolveUsernameRequest
from telethon.tl.functions.messages import GetFullChatRequest
from telethon.tl.types import InputChannel
from telethon.tl.types import InputPeerEmpty
from telethon.tl.types import User
from telethon.tl.types import ChannelParticipant
from telethon.tl.types import ChannelParticipantsKicked # import type to use as filter
from telethon.tl.types import ChannelParticipantsRecent
from telethon.tl.types import ChannelAdminLogEventActionParticipantJoin
from telethon.tl.types import ChannelParticipantsSearch
from telethon.tl.types import UpdateUserStatus
import telepot
from telepot.loop import MessageLoop
from telepot.namedtuple import InlineKeyboardMarkup, InlineKeyboardButton
from telethon.tl.functions.messages import StartBotRequest
#from telethon.tl.types import ChannelAdminLogEventAction
import asyncio
from datetime import datetime
import time

from telegram.ext import (
    Updater,
    CommandHandler,
    CallbackQueryHandler,
    PollAnswerHandler,
    PollHandler,
    MessageHandler,
    Filters,
)

import telebot

api_id = 3409046
api_hash = '48ae9fbdf79edda291e1fa5796fc4665'
#phone_number = '+528132341246'
channel = '@pruebastienda'
offset = 0
limit = 100
all_participants = []
#all_participants = client.get_participants(channel)
users = []
################################################
#      Create the client and connect
client = TelegramClient('newsession', api_id, api_hash)  # feel free to edit %sessionname% as you want
#client.connect() # logining and connecting to Telegram servers
client.start()
 
global lista1
lista1=[]

@client.on(events.UserUpdate)
async def handler(event):
    #miid=event.user_id
    global lista1

    if event.online:
        print("Evento")
        #await enlistar()
        #await main()
        #await Bienvenido(miid)
        #print('lista1:' + str(lista1))
        lista2 = []
        participants2 = await client(GetParticipantsRequest(channel,ChannelParticipantsSearch(''),0,0,hash=0))
        new_users = []
        new_users.clear()
        #print(new_users)
        
        for u in participants2.users:

            #if u.username is None :
	           # u.username = []
           # fullstring = u.username
            #substring = "_bot"

            #if substring in fullstring:
                   # print ("Found! ")
           # else:
                    #print ("Not found!" + u.username)
            lista2.append([u.id, u.username])

           
        #print('lista2:' + str(lista2[0]) , str(lista2[1]))
        for us in lista2:
            if us[0] in lista1:
               a=1
            else:
                new_users.append(us)
               # print('new user: ' + str(us) )
        

        for i in new_users:
            print('id:' + str(i[0]) , 'user: '+ str(i[1]))
            #print('i=' + str(i[0]))
            mensaje="➡️ Hola ¿Cómo estás?  @"  + str(i[1]) + " , Bienvenido a NEGOCIO GAMER, 😁 \n"  \
                    "➡️ Te comento brevemente ,somos un equipo de 8 personas, en donde nos vamos a encargar de brindarte una excelente atención y asesoramiento para que puedas realizar tus ventas de la mejor manera 😉 \n"  \
                    "➡️ Nos dedicamos a la venta de juegos de Playstation 4 y también de Giftcard. \n" \
                    "➡️ Nuestros productos son originales, por lo que ofrecemos garantía de por vida por cada uno de ellos. \n" \
                    "➡️ Contamos con Servicio técnico PROPIO , para resolver cualquier duda o inconveniente que tengas a la brevedad. \n" \
                    "➡️ Contamos con más de 1 año de experiencia en el rubro y trabajamos con más de 1500 revendedores."

            keyboard = InlineKeyboardMarkup(inline_keyboard=[
                   [InlineKeyboardButton(text='Press me', callback_data='press')],
               ])

            #bot.sendMessage(chat_id, 'Use inline keyboard', reply_markup=keyboard
            await client.send_message('@pruebastienda',mensaje)
            await client.send_message(i[0],mensaje)
            #await client.send_message(i, mensaje)
            #request = StartBotRequest("dante_dog_bot", "dante_dog_bot", "params_string")
            #result = await client(request)

            TOKEN = '1686414837:AAEinjhPgAMJD8ABV_hD6rCtJ2jsbXwVCm0'
            bot = telebot.TeleBot(TOKEN)

            #print("Enviar msj " + str(i[1]))
            if i[0]!=  1686414837:
                try:
                    print("Enviado")
                    #bot.send_message(1204307512, 'mensaje de prueba')
                except:
                    print("An exception occurred")
                
               # print('mensaje enviado a ' + str(i[0]))
           
            new_users.remove(i)
            lista1.append(i[0])
               # main()
        #lista1 = lista2
       # print('lista1:' + str(lista1))
        print('finalizo el evento')

# content of the automatic reply

message=" Te comento como nos manejamos : \n"   \
"▪️ Primero que nada tene en claro que no necesitas inversion, simplemente ofreces los juegos disponibles que tenemos , cuando vendes, nos abonas, y a los 30 minutos que impacte el pago te enviamos el juego a tu mail. \n"   \
"▪️ En el mail te llega el juego junto al instructivo de instalacion y un video tutorial para que tu cliente se pueda guiar mientras lo instala. \n"   \
"▪️ Todo nuestro stock disponible con el respectivo precio lo podes ver en tiempo real en el link de nuestro excel."

if __name__ == '__main__':
    # Create the client and connect
    # use sequential_updates=True to respond to messages one at a time
    #client = TelegramClient(session_file, api_id, api_hash, sequential_updates=True)
    #client = TelegramClient('newsession', api_id, api_hash)
    
    @client.on(events.NewMessage(incoming=True))
    async def handle_new_message(event):
        if event.is_private:  # only auto-reply to private chats
            from_ = await event.client.get_entity(event.from_id)  # this lookup will be cached by telethon
            if not from_.bot:  # don't auto-reply to bots
                print(time.asctime(), '-', event.message)  # optionally log time and message
                time.sleep(1)  # pause for 1 second to rate-limit automatic replies
                await event.respond(message)


    print(time.asctime(), '-', 'Auto-replying...')
    #client.connect() # logining and connecting to Telegram servers
    client.start()
    client.run_until_disconnected()
    print(time.asctime(), '-', 'Stopped!')






loop = asyncio.get_event_loop()
#def main():
#    enlistar()
#async def enlistar():
    # global all_participants
#    print(' lista1:'  + str(main.lista1))
#async def enviar():